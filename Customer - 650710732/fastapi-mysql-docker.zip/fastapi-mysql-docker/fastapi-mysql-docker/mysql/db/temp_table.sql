CREATE TABLE Nail_Patterns (
  pattern_id char(4) NOT NULL,
  pattern_Name varchar(45) NOT NULL,
  pattern_Price float,
  PRIMARY KEY (pattern_id)
);
CREATE TABLE Materials (
  spare_id char(4) NOT NULL,
  spare_name varchar(60) NOT NULL,
  spare_Price float,
  PRIMARY KEY (spare_id)
);
CREATE TABLE Customer (
  cust_id char(2) NOT NULL,
  cust_name varchar(100) NOT NULL,
  gender varchar(20) NOT NULL,
  phoneNumber varchar(10),
  PRIMARY KEY (cust_id)
);