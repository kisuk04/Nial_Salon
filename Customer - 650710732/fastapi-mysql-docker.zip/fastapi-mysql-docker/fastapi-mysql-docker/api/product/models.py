from pydantic import BaseModel
from typing import Optional

class ProductModel(BaseModel):
    cust_id:  Optional[str] = None
    cust_name : str
    gender : str
    phoneNumber : str
