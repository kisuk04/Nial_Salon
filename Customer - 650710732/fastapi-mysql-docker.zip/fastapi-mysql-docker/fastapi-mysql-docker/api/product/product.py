from fastapi import HTTPException,APIRouter
from database.query import query_get, query_create, query_update

from .models import ProductModel

def get_all_product():
    products = query_get("""
        SELECT  
            *
        FROM Customer
        """, ())
    return products

def get_product_by_id(cust_id: str):
    product = query_get("""
        SELECT
        *
        FROM Customer
        WHERE cust_id = %s
        """, (cust_id))
    return product

def add_product(product: ProductModel):
    last_row_id = query_create("""
                INSERT INTO Customer (
                    cust_id,
                    cust_name,
                    gender,
                    phoneNumber
                ) VALUES (%s, %s, %s, %s)
                """,
                (
                    product.cust_id,
                    product.cust_name,
                    product.gender,
                    product.phoneNumber
                )
                )
    return last_row_id

def update_product(cust_id: str,product: ProductModel):
    is_update = query_update("""
            UPDATE Customer
                SET cust_name = %s,
                gender = %s,
                phoneNumber = %s
                WHERE cust_id = %s;
            """,
            (
                product.cust_name,
                product.gender,
                product.phoneNumber,
                cust_id
            )
            )
    if is_update:
        product_update_data = product.dict()
        product_update_data.update({"cust_id": cust_id})
        return product_update_data
    else:
        return None
    
def delete_product(cust_id: str):
    is_deleted = query_update("""
        DELETE FROM Customer
        WHERE cust_id = %s;
        """,
        (cust_id,)
        )
    return is_deleted
