from pydantic import BaseModel
from typing import Optional

class ProductModel(BaseModel):
    spare_id: Optional[str] = None
    spare_name: str
    spare_Price: float
